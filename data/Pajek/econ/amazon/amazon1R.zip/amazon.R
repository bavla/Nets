
amazon <- function(fvtx,flnk,ftit,starts,maxver){
# ustvari omrezje knjig s spletisca Amazon
#  amazon('v.txt','a.txt','t.txt',c('0761963391','0521840856','0972028730','0961392150'),30)
# Vladimir Batagelj, 20-21. november 2004
  opis <- function(line){
    i <- regexpr('\">',line); l <- i[1]+attr(i,"match.length")[1]
    j <- regexpr('</a>',line); r <- j[1]-1; substr(line,l,r)
  }
  vid <- new.env(TRUE,NULL)
  vtx <- file(fvtx,"w");  cat('*vertices\n', file=vtx)
  tit <- file(ftit,"w");  cat('*vertices\n', file=tit)
  lnk <- file(flnk,"w");  cat('*arcs\n',file=lnk)
  url1 <- 'http://www.amazon.com/exec/obidos/tg/detail/-/'
  url2 <- '?v=glance'; narc <- 0;  nver <- 0; books <- starts
  for (ib in 1:length(starts)){
    book <- starts[ib]; nver <- nver+1
    assign(book,nver,env=vid)
    cat('new vertex ',nver,' - ',book,'\n')
    page <- paste(url1,book,url2,sep='')
    stran <- readLines(con<-url(page)); close(con)
    i <- grep('<b class="sans">',stran,ignore.case=TRUE)[1]
    l <- length(stran); izrez <- stran[i:l]
    j <- grep("<table",izrez,ignore.case=TRUE)[1]
    izrez <- izrez[1:(j-1)]; izrez <- izrez[izrez != ""]
    t <- izrez[1]; ik <- regexpr('sans">',t);
    ii <- ik+attr(ik,"match.length"); jk <- regexpr('</b>',t)
    t <- substr(t,ii[1],jk[1]-1)
    a <- izrez[2]; jk <- regexpr('">',a); aut <- ""
    while (jk > 0){
      ik <- regexpr('</',a); au <- substr(a,jk+2,ik-1)
      if (aut == '') aut <- au else aut <- paste(aut,', ',au,sep='')
      a <- substr(a,ik+4,nchar(a)); jk <- regexpr('">',a)
    }
    cat(nver, ' "', book, '"\n', sep='', file=vtx)
    cat(nver, ' "', aut, ': ',t, '"\n', sep='', file=tit)
  }

  while (length(books)>0){
    bk <- books[1]; books <- books[-1]
    vini <- get(bk,env=vid); cat(vini,'\n')
    page <- paste(url1,bk,url2,sep='')
    stran <- readLines(con<-url(page)); close(con)
    i <- grep("Customers who bought",stran,ignore.case=TRUE)[1]
    j <- grep("Explore Similar Items",stran,ignore.case=TRUE)[1]
    if (!is.na(i) & !is.na(j)) {
      izrez <- stran[i:j]; izrez <- izrez[-which(izrez=="")]
      ik <- regexpr("detail/-/",izrez); ii <- ik+attr(ik,"match.length")
      for (k in 1:length(ii)) {
        j <- ii[k];
        if (j > 0) {
          bk <- substr(izrez[k],j,j+9); cat('test',k,bk,'\n')
          if (exists(bk,env=vid,inherits=FALSE)){
            vter <- get(bk,env=vid,inherits=FALSE)
          } else {
            nver <- nver + 1; vter <- nver; line <- izrez[k]
            assign(bk,nver,env=vid)
            if (nver <= maxver) {books <- append(books,bk)}
            cat(nver, ' "', bk, '"\n', sep='', file=vtx)
            cat('new vertex ',nver,' - ',bk,'\n');
            t <- opis(line); line <- izrez[k+1]
            if (substr(line,1,2)=='by') {a <- opis(line)}
              else { a <- 'UNKNOWN' }
            cat(nver, ' "', a, ': ', t, '"\n', sep='', file=tit)
          }
          narc <- narc + 1; cat(vini,vter,'\n', file=lnk)
        }
      }
      flush.console()
    }
  }
  close(lnk); close(vtx); close(tit); cat('Amazon - END\n')
}

# amazon('v.txt','a.txt','t.txt',c('0761963391'),30)
