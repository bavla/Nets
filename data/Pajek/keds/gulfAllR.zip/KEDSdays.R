# KEDSdays
# recoding of KEDS files into Pajek's multirelational temporal files
# granularity is 1 day
# ------------------------------------------------------------------
# Vladimir Batagelj, 27. November 2004
# ------------------------------------------------------------------
# Usage:
#   KEDSdays(KEDS_file,Pajek_file)
# Examples:
#   KEDSdays('test.dat','test.net')
#   KEDSdays('gulf.dat','gulfDays.net')
# ------------------------------------------------------------------
# http://www.ku.edu/~keds/data.html
# ------------------------------------------------------------------

KEDSdays <- function(fdat,fnet){

  get.codes <- function(line){
    nlin <<- nlin + 1;
    z <- unlist(strsplit(line," ")); z <- z[z != ""]
    if (length(z)>4) {
      t <- as.numeric(z[1]);
      if (is.na(t)) cat('*** NA in', nlin,'\n') else if (t<t0) t0 <<- t
      u <- z[2]; v <- z[3]; r <- z[4]
      h <- paste(z[5:length(z)],collapse=' ')
      if (!exists(u,env=act,inherits=FALSE)){
        nver <<- nver + 1; assign(u,nver,env=act)}
      if (!exists(v,env=act,inherits=FALSE)){
        nver <<- nver + 1; assign(v,nver,env=act)}
      if (!exists(r,env=rel,inherits=FALSE)) assign(r,h,env=rel)
    } else cat('*** short', nlin,'\n')
  }

  recode <- function(line){
    nlin <<- nlin + 1;
    z <- unlist(strsplit(line," ")); z <- z[z != ""]
    if (length(z)>4) { t <- as.numeric(z[1])
      cat(as.numeric(z[4]),': ',get(z[2],env=act,inherits=FALSE),
        ' ',get(z[3],env=act,inherits=FALSE),' 1 [',
        Days(t %% 100,(t %% 10000) %/% 100,1900 + t %/% 10000) - t0,
        ']\n',sep='',file=net)
    }
  }

  Days <- function(d, m, y){
    p <- (0 == y %% 4) & (0 != y %% 100) | (0 == y %% 400)
    z <- y - 1; n <- z %/% 4 - z %/% 100 + z %/% 400
    n <- n + 365*y + 30*(m - 1) + d + e[m]
    if (p & (m > 2)) {n <-  n + 1}
    n
  }

  cat('KEDSdays: KEDS -> Pajek\n')
  ts <- strsplit(as.character(Sys.time())," ")[[1]][2]
  e <- c(1,2,0,1,1,2,2,3,4,4,5,5)
  act <- new.env(TRUE,NULL); rel <- new.env(TRUE,NULL)
  dat <- file(fdat,"r"); net <- file(fnet,"w")
  # lst <- file('keds.dbg',"w"); dni <- 0
  nver <- 0; t0 <- 9999999; nlin <- 0; copy <- TRUE
  while (copy) {line <- readLines(dat,n=1)
    if (length(line)>0) get.codes(line) else copy <- FALSE }
  close(dat);
  a <- sort(ls(envir=act)); n <- length(a)
  cat(paste('% Recoded by KEDSdays,',date()),"\n",file=net)
  cat("% from http://www.ku.edu/~keds/data.html\n",file=net)
  cat("*vertices",n,"\n",file=net)
  for(i in 1:n){ assign(a[i],i,env=act);
    cat(i,' "',a[i],'" [1-*]\n',sep='',file=net) }
  b <- sort(ls(envir=rel)); m <- length(b)
  for(i in 1:m){ assign(a[i],i,env=act);
  cat("*arcs :",as.numeric(b[i]),' "',
  get(b[i],env=rel,inherits=FALSE),'"\n',sep='',file=net) }
  t0 <- Days(t0 %% 100,(t0 %% 10000) %/% 100,1900 + t0 %/% 10000) - 1
  cat("*arcs\n",file=net); nlin <- 0
  dat <- file(fdat,"r"); copy <- TRUE
  while (copy) {line <- readLines(dat,n=1)
    if (length(line)>0) recode(line) else copy <- FALSE }
  close(dat);
  cat(' ',nlin,'lines processed\n'); close(net)
  te <- strsplit(as.character(Sys.time())," ")[[1]][2]
  cat('  start:',ts,'  finish:',te,'\n')
}

# KEDSdays('test.dat','test.net')
KEDSdays('Gulf99all.dat','gulfADays.net')


