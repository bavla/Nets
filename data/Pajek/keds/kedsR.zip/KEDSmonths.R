# KEDSmonths
# recoding of KEDS files into Pajek's multirelational temporal files
# granularity is 1 month
# ------------------------------------------------------------------
# Vladimir Batagelj, 27. November 2004
# ------------------------------------------------------------------
# Usage:
#   KEDSmonths(KEDS_file,Pajek_file)
# Examples:
#   KEDSmonths('test.dat','test.net')
#   KEDSmonths('gulf.dat','gulfMonths.net')
# ------------------------------------------------------------------
# http://www.ku.edu/~keds/data.html
# ------------------------------------------------------------------

KEDSmonths <- function(fdat,fnet){

  get.codes <- function(line){
    z <- unlist(strsplit(line," ")); z <- z[z != ""]
    if (length(z)>4) {
      t <- as.numeric(z[1]); if (t<t0) t0 <<- t
      u <- z[2]; v <- z[3]; r <- z[4]
      h <- paste(z[5:length(z)],collapse=' ')
      if (!exists(u,env=act,inherits=FALSE)){
        nver <<- nver + 1; assign(u,nver,env=act) }
      if (!exists(v,env=act,inherits=FALSE)){
        nver <<- nver + 1; assign(v,nver,env=act) }
      if (!exists(r,env=rel,inherits=FALSE)) assign(r,h,env=rel)
    }
  }

  recode <- function(line){
    nlin <<- nlin + 1;
    z <- unlist(strsplit(line," ")); z <- z[z != ""]
    if (length(z)>4) { t <- as.numeric(z[1])
      cat(as.numeric(z[4]),': ',get(z[2],env=act,inherits=FALSE),
        ' ',get(z[3],env=act,inherits=FALSE),' 1 [',
        12*(1900 + t %/% 10000) + (t %% 10000) %/% 100 - t0,
        ']\n',sep='',file=net)
    }
  }

  cat('KEDSmonths: KEDS -> Pajek\n')
  ts <- strsplit(as.character(Sys.time())," ")[[1]][2]
  act <- new.env(TRUE,NULL); rel <- new.env(TRUE,NULL)
  dat <- file(fdat,"r"); net <- file(fnet,"w")
  # lst <- file('keds.dbg',"w"); dni <- 0
  nver <- 0; t0 <- 9999999
  lines <- readLines(dat); close(dat)
  sapply(lines,get.codes)
  a <- sort(ls(envir=act)); n <- length(a)
  cat(paste('% Recoded by KEDSmonths,',date()),"\n",file=net)
  cat("*vertices",n,"\n",file=net)
  for(i in 1:n){ assign(a[i],i,env=act);
    cat(i,' "',a[i],'" [1-*]\n',sep='',file=net) }
  b <- sort(ls(envir=rel)); m <- length(b)
  for(i in 1:m){ assign(a[i],i,env=act);
  cat("*arcs :",as.numeric(b[i]),' "',
  get(b[i],env=rel,inherits=FALSE),'"\n',sep='',file=net) }
  t0 <- 12*(1900 + t0 %/% 10000) # + (t0 %% 10000) %/% 100 - 1
  cat("*arcs\n",file=net); nlin <- 0
  sapply(lines,recode)
  cat(' ',nlin,'lines processed\n'); close(net)
  te <- strsplit(as.character(Sys.time())," ")[[1]][2]
  cat('  start:',ts,'  finish:',te,'\n')
}

# KEDSmonths('test.dat','test.net')
KEDSmonths('gulf.dat','gulfLMonths.net')


