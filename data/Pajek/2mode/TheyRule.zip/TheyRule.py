#!/usr/bin/python

#############################################################################
#
#   TheyRule - SQL -> NET
#
#   TheyRule.run('TheyRule.sql')
#
#   import sys; sys.path.append(r'D:\Vlado\work\Python\TheyRule')
#
#   import TheyRule; TheyRule.run('theyrule2004.sql')
#
#   reload(TheyRule); TheyRule.run('theyrule2004.sql')
#
#   Vladimir Batagelj,  21. november 2004
#
#   TheyRule.2004: maxp=500; maxo=6911; maxu=17
#
###############################################################################

import string, os

def run(sqlfile):
#
   workdir = 'd:\\vlado\\work\\python\\TheyRule\\'
   nodes  = open(workdir+'TheyRule.net', 'w')
   nodes.write('*vertices \n')
   names  = open(workdir+'TheyRule.nam', 'w')
   names.write('*vertices \n')
   links  = open(workdir+'TheyRule.lnk', 'w')
   links.write('*arcslist \n')
   l = []
   for i in range(1,7500) : l.append('0')
   sql  = open(workdir+sqlfile, 'r')
   nr = 0
   maxo = 0; maxp = 0; maxu = 0;
   for line in sql.readlines() :
      k = line[:6]
      nr = nr + 1
      if (k == 'INSERT') :
         LL   = line.split(', ')
         num  = int(LL[0].split("(")[1])
         name = LL[1][1:-1]
         tip  = LL[0][19:23]
#         if nr % 10 == 0 : print nr, num, tip, name
         if tip == 'comp' :
            unum = 6911+num
            neig = LL[2]
            snam = LL[6].split(")")[0][1:-1]
            if snam == '': snam = '***'
            if num > maxp : maxp = num
            if neig == '' : print 'poglej', nr
            l[unum] = 'comp'
         elif tip == 'dire' :
            unum = num
            snam = LL[2][1:-1]
            name = name + snam
            neig = ''
            if num > maxo : maxo = num
            l[unum] = LL[3]
         else:
            unum = 7411+num
            snam = LL[7].split(")")[0][1:-1]
            neig = LL[4]
            if num > maxu : maxu = num
            l[unum] = 'inst'
         nodes.write(str(unum)+'  "'+name+'"\n')
         names.write(str(unum)+'  "'+snam+'"\n')
         if neig != '' : links.write(str(unum)+'  '+neig[1:-1]+'\n')

#
   clust  = open(workdir+'TheyRule.clu', 'w')
   clust.write('*vertices \n')
   for i in range(1,7429) : clust.write(l[i]+'\n')
   print maxp, maxo, maxu
   sql.close()
   nodes.close()
   names.close()
   links.close()
   clust.close()
